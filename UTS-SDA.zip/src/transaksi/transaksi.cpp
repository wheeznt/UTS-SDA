#include "transaksi.h"

void pinjamBuku(Mahasiswa *mhs) {
    if (headBuku == NULL) {
        cout << "\nBelum ada buku yang tersedia." << endl;
        return;
    }

    cout << "\n=== Daftar Buku Tersedia ===" << endl;
    Buku *curr = headBuku;
    int no = 1;
    int jumlahTersedia = 0;
    while (curr != NULL) {
        if (curr->stok > 0) {
            cout << no << ". " << curr->judul << " (" << curr->author << ", "
                 << curr->tahunTerbit << ") - Stok: " << curr->stok << endl;
            jumlahTersedia++;
        }
        curr = curr->next;
        no++;
    }

    if (jumlahTersedia == 0) {
        cout << "Semua buku sedang habis stoknya." << endl;
        return;
    }

    int pilih = inputIntUnbound("\nPilih nomor buku yang ingin dipinjam: ", 1);

    Buku *target = NULL;
    curr = headBuku;
    no = 1;
    while (curr != NULL) {
        if (curr->stok > 0 && no == pilih) {
            target = curr;
            break;
        }
        if (curr->stok > 0) {
            no++;
        }
        curr = curr->next;
    }

    if (target == NULL) {
        cout << "Nomor buku tidak valid!" << endl;
        return;
    }

    Peminjaman *cek = mhs->daftarPinjaman;
    while (cek != NULL) {
        if (strcmp(cek->judulBuku, target->judul) == 0
            && strcmp(cek->authorBuku, target->author) == 0) {
            cout << "Kamu sudah meminjam buku ini!" << endl;
            return;
        }
        cek = cek->next;
    }

    target->stok--;

    Peminjaman *baru = new Peminjaman;
    strncpy(baru->judulBuku, target->judul, MAX_JUDUL - 1);
    baru->judulBuku[MAX_JUDUL - 1] = '\0';
    strncpy(baru->authorBuku, target->author, MAX_AUTHOR - 1);
    baru->authorBuku[MAX_AUTHOR - 1] = '\0';
    baru->tahunTerbit = target->tahunTerbit;
    baru->next = NULL;

    if (mhs->daftarPinjaman == NULL) {
        mhs->daftarPinjaman = baru;
    } else {
        baru->next = mhs->daftarPinjaman;
        mhs->daftarPinjaman = baru;
    }

    cout << "Buku \"" << target->judul << "\" berhasil dipinjam!" << endl;
}

void lihatPinjaman(Mahasiswa *mhs) {
    cout << "\n=== Riwayat Peminjaman ===" << endl;
    cout << "Mahasiswa: " << mhs->nama << " (" << mhs->nim << ")" << endl;
    cout << "-------------------------------------------------------" << endl;

    if (mhs->daftarPinjaman == NULL) {
        cout << "Belum ada buku yang dipinjam." << endl;
        return;
    }

    Peminjaman *curr = mhs->daftarPinjaman;
    int no = 1;
    while (curr != NULL) {
        cout << no << ". " << curr->judulBuku << endl;
        cout << "   Pengarang    : " << curr->authorBuku << endl;
        cout << "   Tahun Terbit : " << curr->tahunTerbit << endl;
        curr = curr->next;
        no++;
    }
}

void kembalikanBuku(Mahasiswa *mhs) {
    if (mhs->daftarPinjaman == NULL) {
        cout << "\nKamu tidak sedang meminjam buku apapun." << endl;
        return;
    }

    lihatPinjaman(mhs);
    int pilih = inputIntUnbound("Pilih nomor buku yang ingin dikembalikan: ", 1);

    Peminjaman *curr = mhs->daftarPinjaman;
    Peminjaman *prev = NULL;
    int idx = 1;
    while (curr != NULL && idx < pilih) {
        prev = curr;
        curr = curr->next;
        idx++;
    }

    if (curr == NULL) {
        cout << "Nomor tidak valid!" << endl;
        return;
    }

    bool bukuDitemukan = false;
    Buku *bk = headBuku;
    while (bk != NULL) {
        if (strcmp(bk->judul, curr->judulBuku) == 0) {
            bk->stok++;
            bukuDitemukan = true;
            break;
        }
        bk = bk->next;
    }

    if (!bukuDitemukan) {
        cout << "Warning: Buku \"" << curr->judulBuku << "\" tidak ditemukan di katalog." << endl;
        cout << "Record peminjaman tetap dihapus tanpa menambah stok." << endl;
    }

    if (prev == NULL) {
        mhs->daftarPinjaman = curr->next;
    } else {
        prev->next = curr->next;
    }

    cout << "Buku \"" << curr->judulBuku << "\" berhasil dikembalikan!" << endl;
    delete curr;
}
