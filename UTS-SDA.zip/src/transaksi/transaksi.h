#ifndef TRANSAKSI_H
#define TRANSAKSI_H

#include "../common/common.h"

// ============ FUNGSI PEMINJAMAN ============
void pinjamBuku(Mahasiswa *mhs);
void lihatPinjaman(Mahasiswa *mhs);
void kembalikanBuku(Mahasiswa *mhs);

#endif // TRANSAKSI_H
