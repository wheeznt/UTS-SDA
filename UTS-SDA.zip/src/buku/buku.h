#ifndef BUKU_H
#define BUKU_H

#include "../common/common.h"

// ============ VARIABEL GLOBAL ============
extern Buku *headBuku;
extern Buku *tailBuku;

// ============ FUNGSI BUKU (CRUD) ============

void tambahBuku();
void tampilkanBuku();
void ubahBuku();
void hapusBuku();

// ============ FUNGSI PENCARIAN BUKU ============
Buku* cariBukuByNomor(int nomor);
bool cekBukuSedangDipinjam(const char *judul);

#endif // BUKU_H
