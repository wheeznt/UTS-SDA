#include "buku.h"

// ============ DEFINISI VARIABEL GLOBAL ============
Buku *headBuku = NULL;
Buku *tailBuku = NULL;

// ============ FUNGSI BUKU ============

void tambahBuku() {
    Buku *baru = new Buku;
    cout << "\n=== Tambah Buku Baru ===" << endl;

    inputString("Judul       : ", baru->judul, MAX_JUDUL);
    inputString("Pengarang   : ", baru->author, MAX_AUTHOR);
    baru->tahunTerbit = inputIntUnbound("Tahun Terbit: ", 1);
    baru->stok = inputIntUnbound("Stok        : ", 0);

    baru->prev = NULL;
    baru->next = NULL;

    if (headBuku == NULL) {
        headBuku = baru;
        tailBuku = baru;
    } else {
        tailBuku->next = baru;
        baru->prev = tailBuku;
        tailBuku = baru;
    }
    cout << "Buku berhasil ditambahkan!" << endl;
}

void tampilkanBuku() {
    if (headBuku == NULL) {
        cout << "\nBelum ada data buku." << endl;
        return;
    }
    cout << "\n=======================================================" << endl;
    cout << "                    DAFTAR BUKU                        " << endl;
    cout << "=======================================================" << endl;

    Buku *curr = headBuku;
    int no = 1;
    while (curr != NULL) {
        cout << no << ". " << curr->judul << endl;
        cout << "   Pengarang    : " << curr->author << endl;
        cout << "   Tahun Terbit : " << curr->tahunTerbit << endl;
        cout << "   Stok         : " << curr->stok << endl;
        cout << "-------------------------------------------------------" << endl;
        curr = curr->next;
        no++;
    }
}

Buku* cariBukuByNomor(int nomor) {
    Buku *curr = headBuku;
    int no = 1;
    while (curr != NULL) {
        if (no == nomor) return curr;
        curr = curr->next;
        no++;
    }
    return NULL;
}

bool cekBukuSedangDipinjam(const char *judul) {
    Mahasiswa *mhs = headMhs;
    while (mhs != NULL) {
        Peminjaman *p = mhs->daftarPinjaman;
        while (p != NULL) {
            if (strcmp(p->judulBuku, judul) == 0) {
                return true;
            }
            p = p->next;
        }
        mhs = mhs->next;
    }
    return false;
}

void ubahBuku() {
    if (headBuku == NULL) {
        cout << "\nBelum ada data buku." << endl;
        return;
    }
    tampilkanBuku();

    int pilih = inputIntUnbound("Pilih nomor buku yang ingin diubah: ", 1);

    Buku *target = cariBukuByNomor(pilih);
    if (target == NULL) {
        cout << "Nomor buku tidak ditemukan!" << endl;
        return;
    }

    cout << "\n=== Ubah Data Buku ===" << endl;
    cout << "(Kosongkan jika tidak ingin mengubah, ketik '-' lalu enter)" << endl;

    char buffer[MAX_BUFFER];
    cout << "Judul baru [" << target->judul << "]: ";
    cin.getline(buffer, MAX_BUFFER);
    if (strcmp(buffer, "-") != 0 && strlen(buffer) > 0) {
        if (strlen(buffer) >= MAX_JUDUL) {
            cout << "  Judul terlalu panjang, maks " << (MAX_JUDUL - 1) << " karakter. Tidak diubah." << endl;
        } else {
            strcpy(target->judul, buffer);
        }
    }

    cout << "Pengarang baru [" << target->author << "]: ";
    cin.getline(buffer, MAX_BUFFER);
    if (strcmp(buffer, "-") != 0 && strlen(buffer) > 0) {
        if (strlen(buffer) >= MAX_AUTHOR) {
            cout << "  Pengarang terlalu panjang, maks " << (MAX_AUTHOR - 1) << " karakter. Tidak diubah." << endl;
        } else {
            strcpy(target->author, buffer);
        }
    }

    cout << "Tahun terbit baru [" << target->tahunTerbit << "] (-1 = skip): ";
    int thn = inputIntUnbound("", 1);
    if (thn != -1) target->tahunTerbit = thn;

    cout << "Stok baru [" << target->stok << "] (-1 = skip): ";
    int s = inputInt("", 0, 9999, -1);
    if (s != -1) {
        if (s < 0) {
            cout << "  Stok tidak boleh negatif. Tidak diubah." << endl;
        } else {
            target->stok = s;
        }
    }

    cout << "Data buku berhasil diubah!" << endl;
}

void hapusBuku() {
    if (headBuku == NULL) {
        cout << "\nBelum ada data buku." << endl;
        return;
    }
    tampilkanBuku();

    int pilih = inputIntUnbound("Pilih nomor buku yang ingin dihapus: ", 1);

    Buku *target = cariBukuByNomor(pilih);
    if (target == NULL) {
        cout << "Nomor buku tidak ditemukan!" << endl;
        return;
    }

    if (cekBukuSedangDipinjam(target->judul)) {
        cout << "\nBuku \"" << target->judul << "\" tidak bisa dihapus!" << endl;
        cout << "Buku tersebut sedang dipinjam oleh mahasiswa." << endl;
        cout << "Harap minta mahasiswa mengembalikan buku terlebih dahulu." << endl;
        return;
    }

    if (target == headBuku && target == tailBuku) {
        headBuku = NULL;
        tailBuku = NULL;
    } else if (target == headBuku) {
        headBuku = headBuku->next;
        headBuku->prev = NULL;
    } else if (target == tailBuku) {
        tailBuku = tailBuku->prev;
        tailBuku->next = NULL;
    } else {
        target->prev->next = target->next;
        target->next->prev = target->prev;
    }

    cout << "Buku \"" << target->judul << "\" berhasil dihapus!" << endl;
    delete target;
}
