#include "user.h"

// ============ DEFINISI VARIABEL GLOBAL ============
Mahasiswa *headMhs = NULL;

// ============ FUNGSI ADMIN ============

bool loginAdmin() {
    char username[MAX_USERNAME];
    char password[MAX_PASSWORD];
    int percobaan = 3;

    cout << "\n=== Login Admin ===" << endl;
    while (percobaan > 0) {
        cout << "Username: ";
        cin.getline(username, MAX_USERNAME);
        cout << "Password: ";
        cin.getline(password, MAX_PASSWORD);

        if (strcmp(username, "admin") == 0 && strcmp(password, "admin123") == 0) {
            cout << "Login berhasil! Selamat datang, Admin." << endl;
            return true;
        }

        percobaan--;
        if (percobaan > 0) {
            cout << "Username atau password salah! Sisa percobaan: " << percobaan << endl;
        } else {
            cout << "Gagal login! Percobaan habis." << endl;
        }
    }
    return false;
}

// ============ FUNGSI MAHASISWA ============

Mahasiswa* cariMahasiswa(const char *nim) {
    Mahasiswa *curr = headMhs;
    while (curr != NULL) {
        if (strcmp(curr->nim, nim) == 0)
            return curr;
        curr = curr->next;
    }
    return NULL;
}

Mahasiswa* registrasiMahasiswa(const char *nimInput) {
    if (cariMahasiswa(nimInput) != NULL) {
        cout << "\nNIM " << nimInput << " sudah terdaftar!" << endl;
        return NULL;
    }

    Mahasiswa *baru = new Mahasiswa;
    cout << "\n=== Registrasi Mahasiswa Baru ===" << endl;
    cout << "NIM           : " << nimInput << " (otomatis)" << endl;
    strcpy(baru->nim, nimInput);

    inputString("Nama          : ", baru->nama, MAX_NAMA);
    inputString("Buat Password : ", baru->password, MAX_PASSWORD);
    inputString("Program Studi : ", baru->prodi, MAX_PRODI);
    baru->angkatan = inputIntUnbound("Tahun Angkatan: ", 2000);
    inputString("Nomor HP      : ", baru->noHp, MAX_NOHP);

    baru->daftarPinjaman = NULL;
    baru->next = NULL;

    if (headMhs == NULL) {
        headMhs = baru;
    } else {
        baru->next = headMhs;
        headMhs = baru;
    }

    cout << "Registrasi berhasil! Selamat datang, " << baru->nama << endl;
    return baru;
}

Mahasiswa* loginMahasiswa() {
    char nim[MAX_NIM];
    cout << "\n=== Login Mahasiswa ===" << endl;
    cout << "Masukkan NIM: ";
    cin.getline(nim, MAX_NIM);

    while (strlen(nim) == 0) {
        cout << "NIM tidak boleh kosong! Masukkan NIM: ";
        cin.getline(nim, MAX_NIM);
    }

    Mahasiswa *mhs = cariMahasiswa(nim);
    if (mhs != NULL) {
        char pw[MAX_PASSWORD];
        cout << "Password    : ";
        cin.getline(pw, MAX_PASSWORD);

        if (strcmp(mhs->password, pw) == 0) {
            cout << "Login berhasil! Selamat datang, " << mhs->nama << "!" << endl;
            return mhs;
        } else {
            cout << "Password salah!" << endl;
            return NULL;
        }
    }

    cout << "NIM belum terdaftar." << endl;
    char jawab = inputYaTidak("Ingin registrasi sekarang? (y/n): ");
    if (jawab == 'y' || jawab == 'Y') {
        return registrasiMahasiswa(nim);
    }
    return NULL;
}

void tampilProfilMahasiswa(Mahasiswa *mhs) {
    cout << "\n=== Profil Mahasiswa ===" << endl;
    cout << "Nama          : " << mhs->nama << endl;
    cout << "NIM           : " << mhs->nim << endl;
    cout << "Program Studi : " << mhs->prodi << endl;
    cout << "Angkatan      : " << mhs->angkatan << endl;
    cout << "No. HP        : " << mhs->noHp << endl;
}
