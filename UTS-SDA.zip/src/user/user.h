#ifndef USER_H
#define USER_H

#include "../common/common.h"

// ============ VARIABEL GLOBAL ============
extern Mahasiswa *headMhs;

// ============ FUNGSI ADMIN ============
bool loginAdmin();

// ============ FUNGSI MAHASISWA ============
Mahasiswa* cariMahasiswa(const char *nim);
Mahasiswa* loginMahasiswa();
Mahasiswa* registrasiMahasiswa(const char *nimInput);
void tampilProfilMahasiswa(Mahasiswa *mhs);

#endif // USER_H
