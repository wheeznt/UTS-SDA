#include "common/common.h"
#include "user/user.h"
#include "menu/menu.h"

void bersihkanMemori();

int main() {
    int pilih;

    cout << "=======================================================" << endl;
    cout << "    SISTEM MANAJEMEN PERPUSTAKAAN SEDERHANA" << endl;
    cout << "=======================================================" << endl;

    do {
        cout << "\n==============================" << endl;
        cout << "        MENU UTAMA" << endl;
        cout << "==============================" << endl;
        cout << "1. Masuk sebagai Admin" << endl;
        cout << "2. Masuk sebagai Mahasiswa" << endl;
        cout << "0. Keluar" << endl;
        cout << "Pilihan: ";

        if (!(cin >> pilih)) {
            cout << "Pilihan tidak valid! Masukkan angka." << endl;
            resetCin();
            continue;
        }
        resetCin();

        switch (pilih) {
            case 1:
                if (loginAdmin()) {
                    menuAdmin();
                }
                break;
            case 2: {
                Mahasiswa *mhs = loginMahasiswa();
                if (mhs != NULL) {
                    menuMahasiswa(mhs);
                }
                break;
            }
            case 0:
                cout << "\nTerima kasih telah menggunakan sistem perpustakaan!" << endl;
                break;
            default:
                cout << "Pilihan tidak valid!" << endl;
        }
    } while (pilih != 0);

    bersihkanMemori();
    return 0;
}

void bersihkanMemori() {
    Buku *bk = headBuku;
    while (bk != NULL) {
        Buku *temp = bk;
        bk = bk->next;
        delete temp;
    }

    Mahasiswa *mhs = headMhs;
    while (mhs != NULL) {
        Peminjaman *p = mhs->daftarPinjaman;
        while (p != NULL) {
            Peminjaman *tmp = p;
            p = p->next;
            delete tmp;
        }
        Mahasiswa *tmpMhs = mhs;
        mhs = mhs->next;
        delete tmpMhs;
    }
}
