#include "common.h"

void resetCin() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void inputString(const char *prompt, char *buffer, int maxLen) {
    while (true) {
        cout << prompt;
        cin.getline(buffer, maxLen);
        if (strlen(buffer) == 0) {
            cout << "  Input tidak boleh kosong! Coba lagi." << endl;
        } else if (strlen(buffer) >= maxLen - 1) {
            cout << "  Input terlalu panjang! Maksimal " << (maxLen - 1) << " karakter. Coba lagi." << endl;
        } else {
            break;
        }
    }
}

int inputInt(const char *prompt, int minVal, int maxVal, int skipValue) {
    int value;
    while (true) {
        cout << prompt;
        if (!(cin >> value)) {
            cout << "  Input harus berupa angka! Coba lagi." << endl;
            resetCin();
            continue;
        }
        resetCin();

        if (minVal <= skipValue && skipValue <= maxVal) {
            if (value == skipValue) return value;
        }

        if (value < minVal || value > maxVal) {
            cout << "  Input harus antara " << minVal << " - " << maxVal << "! Coba lagi." << endl;
        } else {
            return value;
        }
    }
}

int inputIntUnbound(const char *prompt, int minVal) {
    int value;
    while (true) {
        cout << prompt;
        if (!(cin >> value)) {
            cout << "  Input harus berupa angka! Coba lagi." << endl;
            resetCin();
            continue;
        }
        resetCin();
        if (value < minVal) {
            cout << "  Input tidak boleh kurang dari " << minVal << "! Coba lagi." << endl;
        } else {
            return value;
        }
    }
}

char inputYaTidak(const char *prompt) {
    char jawab;
    while (true) {
        cout << prompt;
        if (!(cin >> jawab)) {
            cout << "  Input tidak valid! Coba lagi." << endl;
            resetCin();
            continue;
        }
        resetCin();
        if (jawab == 'y' || jawab == 'Y' || jawab == 'n' || jawab == 'N') {
            return jawab;
        }
        cout << "  Masukkan 'y' atau 'n'! Coba lagi." << endl;
    }
}
