#ifndef COMMON_H
#define COMMON_H

#include <iostream>
#include <cstring>
#include <limits>

using namespace std;

// ============ KONSTANTA UKURAN BUFFER ============
const int MAX_JUDUL = 100;
const int MAX_AUTHOR = 100;
const int MAX_NAMA = 50;
const int MAX_NIM = 20;
const int MAX_PRODI = 50;
const int MAX_NOHP = 15;
const int MAX_PASSWORD = 30;
const int MAX_USERNAME = 30;
const int MAX_BUFFER = 100;

// ============ STRUCT BUKU (Double Linked List) ============
struct Buku {
    char judul[MAX_JUDUL];
    char author[MAX_AUTHOR];
    int tahunTerbit;
    int stok;
    Buku *prev;
    Buku *next;
};

// ============ STRUCT PEMINJAMAN (Single Linked List) ============
struct Peminjaman {
    char judulBuku[MAX_JUDUL];
    char authorBuku[MAX_AUTHOR];
    int tahunTerbit;
    Peminjaman *next;
};

// ============ STRUCT MAHASISWA (Single Linked List) ============
struct Mahasiswa {
    char nama[MAX_NAMA];
    char nim[MAX_NIM];
    char password[MAX_PASSWORD];
    char prodi[MAX_PRODI];
    int angkatan;
    char noHp[MAX_NOHP];
    Peminjaman *daftarPinjaman;
    Mahasiswa *next;
};

// ============ VARIABEL GLOBAL (extern declaration) ============
extern Buku *headBuku;
extern Buku *tailBuku;
extern Mahasiswa *headMhs;

// ============ HELPER: Reset stream cin ============
void resetCin();

// ============ HELPER: Input string dengan validasi panjang ============
void inputString(const char *prompt, char *buffer, int maxLen);

// ============ HELPER: Input integer dengan validasi range ============
int inputInt(const char *prompt, int minVal, int maxVal, int skipValue);

// ============ HELPER: Input integer (tanpa batas atas) ============
int inputIntUnbound(const char *prompt, int minVal);

// ============ HELPER: Input char ya/tidak ============
char inputYaTidak(const char *prompt);

#endif // COMMON_H
