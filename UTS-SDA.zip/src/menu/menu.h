#ifndef MENU_H
#define MENU_H

#include "../common/common.h"

void menuAdmin();
void menuMahasiswa(Mahasiswa *mhs);

#endif // MENU_H
