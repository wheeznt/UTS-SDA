#include "menu.h"
#include "../buku/buku.h"
#include "../user/user.h"
#include "../transaksi/transaksi.h"

void menuAdmin() {
    int pilih;
    do {
        cout << "\n==============================" << endl;
        cout << "       MENU ADMIN" << endl;
        cout << "==============================" << endl;
        cout << "1. Tampilkan Daftar Buku" << endl;
        cout << "2. Tambah Buku" << endl;
        cout << "3. Ubah Data Buku" << endl;
        cout << "4. Hapus Buku" << endl;
        cout << "0. Kembali ke Menu Utama" << endl;
        cout << "Pilihan: ";

        if (!(cin >> pilih)) {
            cout << "Pilihan tidak valid! Masukkan angka." << endl;
            resetCin();
            continue;
        }
        resetCin();

        switch (pilih) {
            case 1: tampilkanBuku(); break;
            case 2: tambahBuku(); break;
            case 3: ubahBuku(); break;
            case 4: hapusBuku(); break;
            case 0: cout << "Kembali ke menu utama..." << endl; break;
            default: cout << "Pilihan tidak valid!" << endl;
        }
    } while (pilih != 0);
}

void menuMahasiswa(Mahasiswa *mhs) {
    int pilih;
    do {
        cout << "\n==============================" << endl;
        cout << "     MENU MAHASISWA" << endl;
        cout << "==============================" << endl;
        cout << "Halo, " << mhs->nama << "!" << endl;
        cout << "------------------------------" << endl;
        cout << "1. Lihat Daftar Buku" << endl;
        cout << "2. Pinjam Buku" << endl;
        cout << "3. Lihat Buku yang Dipinjam" << endl;
        cout << "4. Kembalikan Buku" << endl;
        cout << "5. Lihat Profil" << endl;
        cout << "0. Logout" << endl;
        cout << "Pilihan: ";

        if (!(cin >> pilih)) {
            cout << "Pilihan tidak valid! Masukkan angka." << endl;
            resetCin();
            continue;
        }
        resetCin();

        switch (pilih) {
            case 1: tampilkanBuku(); break;
            case 2: pinjamBuku(mhs); break;
            case 3: lihatPinjaman(mhs); break;
            case 4: kembalikanBuku(mhs); break;
            case 5: tampilProfilMahasiswa(mhs); break;
            case 0: cout << "Logout berhasil." << endl; break;
            default: cout << "Pilihan tidak valid!" << endl;
        }
    } while (pilih != 0);
}
